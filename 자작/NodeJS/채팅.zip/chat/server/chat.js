// 소켓 io 지정
var io;

// 입력 포트 지정
var port = process.argv[2]*1;


// 허용포트인지 검사
if(port > 4000 || port < 5001) {
	console.log("Connect " + port + " Port!! Server ON!");
	io = require('socket.io').listen(port);
} else if(!port) {
	console.log("Connect 4001 Port!! Server ON!");
	io = require('socket.io').listen(4001);
} else {
	console.log('Not OPEN Port!!');
	process.exit(1);
}


// 시스템 동작 설정
function browser_control(code) {
	// 시작시 그리드 초기화
	if(code == 1){
		var query = "$('#grid').html('');";
	}
	// 시스템 동작 리턴값
    return query;
}


io.sockets.on('connection', function (socket) {

	// 최초 커넥트시 동작 설정
	socket.on('Connect', function (data) {
		var Setting   = eval(data);
		var grid      = Setting.grid;
		var welcome   = Setting.welcome;
		var ChatUser  = Setting.ChatUser;
		var ChatInput = Setting.ChatInput;

		socket.emit('browser_control', {query:browser_control(1)});
		socket.emit('ReturnText', welcome);
		socket.broadcast.emit("ReturnText", "- "+ChatUser+"님께서 접속하셨습니다.<br>");
	});

	// 커넥트가 끊어졌을때
	socket.on('disconnect', function () {
		console.log('disconnect!!');
	});


	// SendText 데이터가 도착 하면
	socket.on('SendText', function (data) {
		// 넘어온 json을 오브젝트화
		var obj = eval(data);
		var Messege = obj.Messege;
		// 치환기능
		Messege = Messege.replace("sir", "<img src='http://sir.co.kr/theme/default/img/common/logo.png' alt='그누보드'>");

		// 클라이언트에게 다시 반환
		socket.emit("ReturnText", "<b>"+obj.User+"(나):</b> "+Messege);
		socket.broadcast.emit("ReturnText", obj.User+": "+Messege);
	});
});