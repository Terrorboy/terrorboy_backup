<!doctype html>
<html lang="ko">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<head>
		<title>Chat</title>
		<script src="http://masoteam.com/web/js/jquery-1.8.3.min.js"></script>
		<script src="http://masoteam.com:4001/socket.io/socket.io.js"></script>
		<script src="chat.js"></script>
	</head>
	<body>
		<table cellpadding=0 cellspacing=0 border=0>
		<tr>
			<td>
		<object id="player" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" name="player" width="320" height="264">
  <param name="movie" value="http://masoteam.com/fms/player.swf" />
  <param name="allowfullscreen" value="true" />
  <param name="allowscriptaccess" value="always" />
  <param name="flashvars" value="streamer=rtmp://wow.masoteam.com/live&file=idel&type=rtmp&autostart=true" />
	<embed type="application/x-shockwave-flash" id="player" name="player" src="http://masoteam.com/fms/player.swf" width="320" height="264" allowscriptaccess="always" 	allowfullscreen="true"  flashvars="streamer=rtmp://wow.masoteam.com/live&file=idel&type=rtmp&autostart=true"/>
</object>
</td>
		
		<td width="50"></td>

		<td valign="top">
		<div id="grid" style="width:400px; height:450px;overflow-y:scroll;">������ �������Դϴ�.</div>
		<div>
			<input type="text" name="name" id="name" size="8" value="<?php if($_GET[nick]){ echo $_GET[nick]; } else { echo "Guest"; } ?>">
			<input type="text" name="text" id="text">
			<input type="button" value="����" id="submit">
		</div>
		</td>
		</tr>
		</table>
	</body>

</html>
