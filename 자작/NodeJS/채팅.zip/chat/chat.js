// 소켓 서버로 접속
var socket = io.connect('http://masoteam.com:4001');

// 기본 환경설정
var welcome   = ":: 즐거운채팅 되세요. ::<br>"; // 초기 접근시 메시지
var grid      = "grid"; // 메시지 출력 영역 아이디
var ChatInput = "text"; // 메시지 입력 인풋 아이디
var ChatUser  = "name"; // 접속자 이름 아이디


// 서버에서 전송된 명령어 처리
socket.on('browser_control', function(data) {
	eval(data.query);
});

// 초기 커넥트 설정
$(function(){
	socket.emit("Connect", {
				"welcome":welcome,
				"grid":grid,
				"ChatInput":ChatInput,
				"ChatUser":$("#"+ChatUser).val()
				});
});


// 서버에서 전송되는 메시지 출력 설정
socket.on('ReturnText', function (data) {
	$("#grid").html($("#grid").html()+data+"<br>");
	// 스크롤 항상 밑으로 고정
	$("#grid").scrollTop($("#grid")[0].scrollHeight);
});


// 메시지전송 함수
var send = function(){
	var Messege = $("#text").val();
	var User = $("#name").val();

	socket.emit("SendText", {"User":User, "Messege":Messege});
	$("#text").val("");
}


// 메시지 전송
$(function(){
	$("#submit").click(function() {
		send();
	});
	$("#text").keyup(function(e) {
		if (e.keyCode == 13) send();
	});
});