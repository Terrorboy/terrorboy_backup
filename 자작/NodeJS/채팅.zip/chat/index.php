<!doctype html>
<html lang="ko">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<head>
		<title>Chat</title>
		<script src="http://masoteam.com/web/js/jquery-1.8.3.min.js"></script>
		<script src="http://masoteam.com:4001/socket.io/socket.io.js"></script>
		<script src="chat.js"></script>
	</head>
	<body>
		<table cellpadding=0 cellspacing=0 border=0>
		<tr>
			<td>
	<param name='movie' value='http://masoteam.com/jwplayer/player/tube_player.swf' />
  <param name='allowfullscreen' value='true' />
  <param name='allowscriptaccess" value="always' />
  <param name='wmode' value='transparent'>   
  <param name='flashvars' value='skin=http://masoteam.com/jwplayer/skin/newtubedark.zip&playlistfile=http://masoteam.com/jwplayer/list/playlist_mov.xml&streamer=rtmp://wow.masoteam.com:1935/vod/mv/&playlistsize=250&controlbar=bottom&playlist=bottom&repeat=list' />
<embed type='application/x-shockwave-flash'     
  id='single2'     
  name='single2'     
  src='http://masoteam.com/jwplayer/player/tube_player.swf'     
  width='960'     
  height='680'     
  bgcolor='undefined'     
  allowscriptaccess='always'     
  allowfullscreen='true'     
  wmode='transparent'     
flashvars='skin=http://masoteam.com/jwplayer/skin/newtubedark.zip&playlistfile=http://masoteam.com/jwplayer/list/playlist_mov.xml&streamer=rtmp://wow.masoteam.com:1935/vod/mv/&playlistsize=250&controlbar=bottom&playlist=bottom&repeat=list'/>     
</object>

</td>
		
		<td width="50"></td>

		<td valign="top">
		<div id="grid" style="width:350px; height:450px;overflow-y:scroll;">서버에 접속중입니다.</div>
		<div>
			<input type="text" name="name" id="name" size="8" value="<?php if($_GET[nick]){ echo $_GET[nick]; } else { echo "Guest"; } ?>">
			<input type="text" name="text" id="text">
			<input type="button" value="전송" id="submit">
		</div>
		</td>
		</tr>
		</table>
	</body>

</html>
